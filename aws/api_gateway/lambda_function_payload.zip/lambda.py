def handler(event, context):
    return {"message": "Message Received"}
